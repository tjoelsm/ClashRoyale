package baseDatos;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @category conecta con access
 * @param NA
 * @author Tiago 
 */

public class Conexion {

	private static final String DB_ACCESS = "D:\\WS_JAVA_V2\\ClashRoyale\\BD\\CR.accdb";
	public static Connection CONEXION = null;

private static String DB_RUTA () {
	
	return ficheros.leerProperties.leerUnaPropertie("DB");
}
	protected static void conectAccess() {
			// TODO Ap�ndice de m�todo generado autom�ticamente		
			  try{
				  //File fichero = new File(DB_ACCESS);
		            String controlador="sun.jdbc.odbc.JdbcOdbcDriver";
		            String DSN="jdbc:odbc:Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ="+DB_RUTA();//+";DriverID=22;READONLY=true"; 
		            String user="";
		            String password="";
		            Class.forName (controlador).newInstance();	        	         	          	            
		            CONEXION=DriverManager.getConnection(DSN,user,password);
		        }
			  	catch(SQLException e){
			  		System.out.println("#### ERROR DE COMUNICACION ##### " + e.getMessage());
			  	}
		        catch (Exception e) {
		        	System.out.println("#### ERROR DE COMUNICACION ##### " + e.getMessage());
		        }
	}
	/**
	 * @category des-conecta con access
	 * @param NA
	 * @author Tiago 
	 */
	protected static void desConectAccess() {
		try {
			if (CONEXION != null)
			{
				CONEXION.close();
			}	
		} catch (SQLException e) {
			System.out.println("#### DES-CONNECT ERROR DE SQLException ##### " + e.getMessage());

		} catch (Exception e) {
			System.out.println("#### DES-CONNECT ERROR ##### " + e.getMessage());
		} 
	}
	
	
}
