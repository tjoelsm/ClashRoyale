package baseDatos;

import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import ficheros.leerficheros;
import sun.util.resources.CalendarData;

public class Stats {
	
	public static Statement SENTENCIA = null;
	private static String QUERY_INS_ALL_STATS = "INSERT INTO stats VALUES (";
	private static String QUERY_SEL_ALL_STATS = "SELECT * FROM stats ";
			
			
	public void consultarStatsHoy(){
		try {
			Statement stmt;
			Conexion.conectAccess();
			stmt = Conexion.CONEXION.createStatement();
			
			
			
			stmt.executeQuery(QUERY_SEL_ALL_STATS);//muestra resultados equivalentes en SQL  a utilizar SELECT
	        ResultSet rs= stmt.getResultSet(); //obtiene el resultado de la consulta y lo guarda en rs
	        if(rs!=null) {
	        	rs.close();
	        }
	        Conexion.desConectAccess();
		} catch (Exception e) {
	    	System.out.println("#### INSERT STATS HOY ERROR ##### " + e.getMessage());
		}
	}
	
	public static void insertStattAll(String datosEntrada) throws SQLException{
		
		
		Calendar c = new GregorianCalendar();
		String dia = Integer.toString(c.get(Calendar.DATE));
		String mes = Integer.toString(c.get(Calendar.MONTH));
		String annio = Integer.toString(c.get(Calendar.YEAR));
		
		if (mes.length()==1){
			mes = '0' + mes;
		}
		
		String fechaHoy = dia + "-" + mes + "-" + annio;
		
		try {
			Statement stmt;
			Conexion.conectAccess();
			stmt = Conexion.CONEXION.createStatement();
			
			String strBuffer[] = datosEntrada.split("\n");
			
			String clan = strBuffer[0].toString().replaceAll("<CLAN>", "").replaceAll("</CLAN>", "");
			
			for(int i=2;i<strBuffer.length;i++){
			
				String strBufferLinea[] = strBuffer[i].split("\t"); 
				
			String EJ_QUERY = QUERY_INS_ALL_STATS + "" + strBufferLinea[0].replaceAll("<RANK>", "").replaceAll("</RANK>", "").replaceAll("#", "") + ","; // Rank NAMBER
			EJ_QUERY += "'";
			EJ_QUERY += leerficheros.trataEtiquetaNombre(strBufferLinea[1].toString().replaceAll("<NAME>", "").replaceAll("</NAME>", ""), "NAME"); // Name, hay que quitar el link
			EJ_QUERY += "',";
			//EJ_QUERY += "'"; // LEVEL NUMBER
			EJ_QUERY += strBufferLinea[2].toString().replaceAll("<LEVEL>", "").replaceAll("</LEVEL>", ""); // Level
			EJ_QUERY += ",";//EJ_QUERY += "',";
			EJ_QUERY += "'";
			if (strBufferLinea.length==6){
					EJ_QUERY += "NO LEAGUE"; // League
					EJ_QUERY += "',";
					//EJ_QUERY += "'";
					EJ_QUERY += strBufferLinea[3].toString().replaceAll("<CUP>", "").replaceAll("</CUP>", ""); // Trophies
					EJ_QUERY += ",";//EJ_QUERY += "',";
					//EJ_QUERY += "'";
					
					String testDon = strBufferLinea[4].toString().replaceAll("<DONATIONS>", "").replaceAll("</DONATIONS>", "");
					
					if(testDon.equals("")){
						testDon = "0";
					}
					
					EJ_QUERY += testDon; // Donations
					EJ_QUERY += ",";//EJ_QUERY += "',";
					EJ_QUERY += "'";
					EJ_QUERY += strBufferLinea[5].toString().replaceAll("<ROLE>", "").replaceAll("</ROLE>", ""); // Role
					EJ_QUERY += "',";EJ_QUERY += "'";
			} else {
					String strLeague = strBufferLinea[3].toString().replaceAll("<LEAGUE>", "").replaceAll("</LEAGUE>", "");
				
					if (strLeague.equals("")){
						strLeague = "NO LEAGUE";
					}
					
					EJ_QUERY += strLeague;//strBufferLinea[3].toString().replaceAll("<LEAGUE>", "").replaceAll("</LEAGUE>", ""); // League
					EJ_QUERY += "',";
					//EJ_QUERY += "'";
					EJ_QUERY += strBufferLinea[4].toString().replaceAll("<CUP>", "").replaceAll("</CUP>", ""); // Trophies
					EJ_QUERY += ",";//EJ_QUERY += "',";
					//EJ_QUERY += "'";
					
					String testDon = strBufferLinea[5].toString().replaceAll("<DONATIONS>", "").replaceAll("</DONATIONS>", "");
					
					if(testDon.equals("")){
						testDon = "0";
					} 					
					EJ_QUERY += testDon;//strBufferLinea[5].toString().replaceAll("<DONATIONS>", "").replaceAll("</DONATIONS>", ""); // Donations
					EJ_QUERY += ",";//EJ_QUERY += "',";
					EJ_QUERY += "'";
					EJ_QUERY += strBufferLinea[6].toString().replaceAll("<ROLE>", "").replaceAll("</ROLE>", ""); // Role
					EJ_QUERY += "',";
					EJ_QUERY += "'";
			}
			EJ_QUERY += fechaHoy;// FechaStats
			EJ_QUERY += "',";EJ_QUERY += "'";
			EJ_QUERY += clan; // Clan
			EJ_QUERY += "'";
			EJ_QUERY += ")"; // cierra
			System.out.println(EJ_QUERY);
			stmt.execute(EJ_QUERY);//muestra resultados equivalentes en SQL  a utilizar SELECT
			}
	        stmt.close();
	        Conexion.desConectAccess();
		} 
		catch (SQLException e) {
			System.out.println("#### INSERT STATS HOY SQLException ##### " + e.getMessage());
		} catch (Exception e) {
	    	System.out.println("#### INSERT STATS HOY Exception ##### " + e.getMessage());
		} finally{
			System.out.println("#### INSERT STATS OK ##### ");
		}
	}
	
}
