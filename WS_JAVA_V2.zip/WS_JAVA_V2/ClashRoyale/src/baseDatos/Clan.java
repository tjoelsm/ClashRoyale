package baseDatos;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author XI304784
 * @category Funcionalidad relacionada en el Clan en general
 */
public class Clan {

	public static Statement SENTENCIA = null;
	private static String QUERY_INS_ALL_CLAN = "INSERT INTO clan VALUES ";
	private static String QUERY_SEL_ALL_CLAN = "SELECT * FROM clan ";
	
	/**
	 * @author XI304784
	 * @param funcion que comprueba si el CALN existe
	 */

	public static boolean existeClan(String Name) throws SQLException{
		
		String EJ_QUERY = QUERY_SEL_ALL_CLAN + "WHERE Nombre=\'" + Name + "\';";
		ResultSet rs = null;
		boolean noHayClan = true;
		try {
			PreparedStatement ptmt;
			Conexion.conectAccess();
			ptmt = Conexion.CONEXION.prepareStatement(EJ_QUERY);		
			rs= ptmt.executeQuery(); //obtiene el resultado de la consulta y lo guarda en rs
			while (rs.next()){        	
				noHayClan = false;
	        }
			
	                

	        if(rs!=null) {
	        	rs.close();
	        }
	        if(ptmt!=null){
	        	ptmt.close();
	        }
	        Conexion.desConectAccess();
	        
		} catch (Exception e) {
	    	System.out.println("#### INSERT Clan ERROR ##### " + e.getMessage());
		}
		return noHayClan;
	}
	
	public void consultarClan(){
		try {
			Statement stmt;
			Conexion.conectAccess();
			stmt = Conexion.CONEXION.createStatement();
			
			
			
			stmt.executeQuery(QUERY_SEL_ALL_CLAN);//muestra resultados equivalentes en SQL  a utilizar SELECT
	        ResultSet rs= stmt.getResultSet(); //obtiene el resultado de la consulta y lo guarda en rs
	        if(rs!=null) {
	        	rs.close();
	        }
	        Conexion.desConectAccess();
		} catch (Exception e) {
	    	System.out.println("#### INSERT Clan HOY ERROR ##### " + e.getMessage());
		}
	}
	
	/**
	 * @category inserta Jugadores caso no exista en la tabla jugador
	 * @param Nombre , Link
	 * @author Tiago
	 * @throws SQLException 
	 *  
	 */
	public static void insertClan(String Nombre, String Link) throws SQLException{

		/** 
		 * Comprobamos que el nombre no viene vacion
		 * En caso que venga vacion, le ponemos el ID al final de la URL de su stats de jugador 
		*/

			if (existeClan(Nombre)){
				try {
					Statement stmt;
					Conexion.conectAccess();
					stmt = Conexion.CONEXION.createStatement();
					String EJ_QUERY = QUERY_INS_ALL_CLAN + "(\'" + Nombre + "\' , \'" + Link + "\')"; 
					stmt.execute(EJ_QUERY);//muestra resultados equivalentes en SQL  a utilizar SELECT
			        stmt.close();
			        Conexion.desConectAccess();
				} catch (SQLException e) {
					System.out.println("#### INSERT Clan HOY SQLException ##### " + e.getMessage());
				} catch (Exception e) {
			    	System.out.println("#### INSERT Clan HOY Exception ##### " + e.getMessage());
				} finally{
					System.out.println("#### INSERT Clan OK ##### " + Nombre);
				}
		}/** else {
			System.out.println("#### Jugador con el Nombre: " + Nombre +" ya existe #####");
		} */
	}
	
	
}
