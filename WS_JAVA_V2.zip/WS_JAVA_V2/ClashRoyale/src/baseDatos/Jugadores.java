package baseDatos;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author XI304784
 * @category Funcionalidad relacionada en Jugadores individualente o en conjunto 
 */
public class Jugadores {
	
	public static Statement SENTENCIA = null;
	private static String QUERY_INS_JUGADOR = "INSERT INTO jugador VALUES ";
	private static String QUERY_SEL_JUGADOR = "SELECT * FROM jugador ";

public void buscarJugadoresAll(){
	
	
	
}	

/**
 * @author XI304784
 * @param funcion que comprueba si el jugador existe
 */

public static boolean existeJugador(String Name) throws SQLException{
	
	String EJ_QUERY = QUERY_SEL_JUGADOR + "WHERE Name=\'" + Name + "\';";
	ResultSet rs = null;
	boolean noHayJugador = true;
	try {
		PreparedStatement ptmt;
		Conexion.conectAccess();
		ptmt = Conexion.CONEXION.prepareStatement(EJ_QUERY);		
		rs= ptmt.executeQuery(); //obtiene el resultado de la consulta y lo guarda en rs
		while (rs.next()){        	
        	noHayJugador = false;
        }
		
                

        if(rs!=null) {
        	rs.close();
        }
        if(ptmt!=null){
        	ptmt.close();
        }
        Conexion.desConectAccess();
        
	} catch (Exception e) {
    	System.out.println("#### INSERT Existe Jugador ERROR ##### " + e.getMessage());
	}
	return noHayJugador;//noHayJugador;
}



/**
 * @category inserta todos los Jugadores
 * @param Nombre , Link
 * @author Tiago
 *  
 */
public static void insertJugador(String Nombre, String Link){
	try {
		Statement stmt;
		Conexion.conectAccess();
		stmt = Conexion.CONEXION.createStatement();
			if(Nombre.trim().equals("")){
				String aux[] = Link.split("/");
				Nombre = aux[aux.length-1];		
			}
		String EJ_QUERY = QUERY_INS_JUGADOR + "(\'" + Nombre + "\' , \'" + Link + "\')"; 
		stmt.execute(EJ_QUERY);//muestra resultados equivalentes en SQL  a utilizar SELECT
        stmt.close();
        Conexion.desConectAccess();
	} catch (SQLException e) {
		System.out.println("#### INSERT Persona HOY SQLException ##### " + e.getMessage());
	} catch (Exception e) {
    	System.out.println("#### INSERT Persona HOY Exception ##### " + e.getMessage());
	} finally{
		System.out.println("#### INSERT Persona OK ##### " + Nombre);
	}
}

/**
 * @category inserta Jugadores caso no exista en la tabla jugador
 * @param Nombre , Link
 * @author Tiago
 * @throws SQLException 
 *  
 */
public static void insertJugadorNuevo(String Nombre, String Link) throws SQLException{

	/** 
	 * Comprobamos que el nombre no viene vacion
	 * En caso que venga vacion, le ponemos el ID al final de la URL de su stats de jugador 
	*/
	if(Nombre.trim().equals("")){
		String aux[] = Link.split("/");
		Nombre = aux[aux.length-1];		
	}

		if (existeJugador(Nombre)==true){
			try {
				Statement stmt;
				Conexion.conectAccess();
				stmt = Conexion.CONEXION.createStatement();
				String EJ_QUERY = QUERY_INS_JUGADOR + "(\'" + Nombre + "\' , \'" + Link + "\')"; 
				stmt.execute(EJ_QUERY);//muestra resultados equivalentes en SQL  a utilizar SELECT
		        stmt.close();
		        Conexion.desConectAccess();
			} catch (SQLException e) {
				System.out.println("#### INSERT Persona HOY SQLException ##### " + e.getMessage());
			} catch (Exception e) {
		    	System.out.println("#### INSERT Persona HOY Exception ##### " + e.getMessage());
			} finally{
				System.out.println("#### INSERT Persona OK ##### " + Nombre);
			}
	} /*else {
		System.out.println("#### Jugador con el Nombre: " + Nombre +" ya existe #####");
	}*/
}


}
