import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import web.consultarWeb;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.sql.SQLException;
import java.awt.event.ActionEvent;

public class ClashRoyale {

	private JFrame frmClashRoyale;
	private JTextField txtPrueba;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ClashRoyale window = new ClashRoyale();
					window.frmClashRoyale.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ClashRoyale() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmClashRoyale = new JFrame();
		frmClashRoyale.setTitle("Clash Royale");
		frmClashRoyale.setBounds(100, 100, 600, 400);
		frmClashRoyale.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmClashRoyale.getContentPane().setLayout(null);
		
		JLabel lblUrlClan = new JLabel("URL CLAN:");
		lblUrlClan.setBounds(10, 33, 62, 14);
		frmClashRoyale.getContentPane().add(lblUrlClan);
		
		txtPrueba = new JTextField();
		String prop  = ficheros.leerProperties.leerUnaPropertie("URL");
		txtPrueba.setText(prop.trim());
		txtPrueba.setBounds(82, 30, 265, 20);
		frmClashRoyale.getContentPane().add(txtPrueba);
		txtPrueba.setColumns(10);
		
		JButton btnAadir = new JButton("A\u00F1adir");
		btnAadir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String FicheroHTML;
				try {
					FicheroHTML = consultarWeb.getContenidoHTML(txtPrueba.getText().trim());
					//String FicheroHTML = ficheros.leerficheros.muestraContenido("C:\\Temp\\pagina\\StatsRoyale_com - Clash Royale Statistics.htm");
					//System.out.println(FicheroHTML);
					baseDatos.Stats.insertStattAll(FicheroHTML);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				

			}
		});
		btnAadir.setBounds(357, 29, 89, 23);
		frmClashRoyale.getContentPane().add(btnAadir);
	}
}
