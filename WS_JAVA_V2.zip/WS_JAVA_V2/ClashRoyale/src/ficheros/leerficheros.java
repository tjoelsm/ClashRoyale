package ficheros;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;


public class leerficheros {

public static String muestraContenido(String archivo) throws FileNotFoundException, IOException {
	
	
	String strFich = "";
	BufferedReader b = null;
    try{
    	String cadena = "";
        FileReader f = new FileReader(archivo);
        b = new BufferedReader(f);
        while((cadena = b.readLine())!=null) {  		

        	//****************************** Trata informcion del Clan ******************************
            if(cadena.contains("ui__headerMedium clan__clanName")) 
            {
            		strFich += trataEtiquetaClan(b.readLine(), "CLAN", "https://statsroyale.com/clan/2q2rruvu");
            		//strFich += trataEtiquetaClan(b.readLine(), "CLAN");
            }
        	//****************************** FIN Trata informcion del Jugador ******************************
        	
        	//****************************** Trata informcion del Jugador ******************************
           if(cadena.contains("clan__headerCaption")) 
            {
            		strFich += trataEtiqueta(cadena, "COL");
            }
        	if(cadena.contains("ui__blueLink")) 
        	{

        		strFich += trataEtiqueta(cadena, "NAME"); // falta quintar el enalce de cada jugador
        	}
        	
        	if(cadena.contains("clan__playerLevel")) 
        	{
        		strFich += trataEtiqueta(cadena, "LEVEL");
        	}
        	if(cadena.contains("league__1")) 
        	{
        		strFich += trataEtiqueta(cadena, "LEAGUE");
        	}
        		
        	if(cadena.contains("clan__cup")) 
        	{ 
        		strFich += trataEtiqueta(cadena, "CUP");
        		if (cadena.contains("clan__cup"))
        		{ // en este caso va leer las dos lineas seguintes que tienen la misma clave "clan__row"
        			strFich += trataEtiqueta(b.readLine(), "DONATIONS");
        			strFich += trataEtiqueta(b.readLine(), "ROLE");		
        		}
        		
        	}
        	
        	if (cadena.contains("clan__rowContainer"))
    		{ // en este caso va leer la lineas seguinte que tienen la misma clave "clan__row"
    			strFich += trataEtiqueta(b.readLine(), "RANK");				
    		}
        	//****************************** FIN Trata informcion del Jugador ****************************** 
        }
        b.close();
        
	}
	catch (IOException | SQLException e){
		
	}
	finally{
			// sin nada a declarar
	}
    return strFich;
}


public static String muestraContenidoWEB(String archivo) throws FileNotFoundException, IOException {
	
	
	String strFich = "";
	String strBuffer[] = archivo.split("\n");
    try{
    	String cadena = "";
        for (int i=50;i<strBuffer.length-1;i++){
        	cadena = strBuffer[i];
        	//****************************** Trata informcion del Clan ******************************
            if(cadena.contains("ui__headerMedium clan__clanName")) 
            {
            		i++;
            		strFich += trataEtiquetaClan(strBuffer[i], "CLAN", "https://statsroyale.com/clan/2q2rruvu");
            		//strFich += trataEtiquetaClan(b.readLine(), "CLAN");
            }
        	//****************************** FIN Trata informcion del Jugador ******************************
        	
        	//****************************** Trata informcion del Jugador ******************************
           if(cadena.contains("clan__headerCaption")) 
            {
            		strFich += trataEtiqueta(cadena, "COL");
            }
        	if(cadena.contains("ui__blueLink")) 
        	{

        		strFich += trataEtiqueta(cadena, "NAME"); // falta quintar el enalce de cada jugador
        	}
        	
        	if(cadena.contains("clan__playerLevel")) 
        	{
        		strFich += trataEtiqueta(cadena, "LEVEL");
        	}
        	if(cadena.contains("league__1")) 
        	{
        		strFich += trataEtiqueta(cadena, "LEAGUE");
        	}
        		
        	if(cadena.contains("clan__cup")) 
        	{ 
        		strFich += trataEtiqueta(cadena, "CUP");
        		if (cadena.contains("clan__cup"))
        		{ // en este caso va leer las dos lineas seguintes que tienen la misma clave "clan__row"
        			i++;
        			i++;
        			strFich += trataEtiqueta(strBuffer[i], "DONATIONS");
        			i++;
        			i++;
        			strFich += trataEtiqueta(strBuffer[i], "ROLE");		
        		}
        		
        	}
        	
        	if (cadena.contains("clan__rowContainer"))
    		{ // en este caso va leer la lineas seguinte que tienen la misma clave "clan__row"
        		i=i+2;
    			strFich += trataEtiqueta(strBuffer[i], "RANK");				
    		}
        	//****************************** FIN Trata informcion del Jugador ****************************** 
        }
	}
	catch (SQLException e){
		
	}
	finally{
			// sin nada a declarar
	}
    return strFich;
}

/**
 * @param cadenaIn
 * @param Etiqueta
 * @return a etiqueta limpia de cada jugador
 * @throws SQLException 
 */
private static String trataEtiqueta (String cadenaIn, String Etiqueta) throws SQLException {
	String strFich = "";
	
	
	if (Etiqueta.equals("NAME")){
		String link = limpiarLineaJugador(cadenaIn);
		strFich = "<" +Etiqueta +" "+ link +"</"+Etiqueta+">";
		
		String[] Name;
		Name = link.split("\"");
		// ################ Conectar para insertar todos los jugadores en caso que no exista
		//baseDatos.Jugadores.insertJugadorNuevo(Name[2].replaceAll(">", ""),Name[1]);
		
	}else{
			strFich = "<" +Etiqueta+">"+ limpiarLineaJugador(cadenaIn) +"</"+Etiqueta+">";	
	}
	
	
	
	if (Etiqueta.equals("ROLE") || limpiarLineaJugador(cadenaIn).equals("Role")){
		strFich += "\n";
	} else {
		strFich += "\t";
	}

	return strFich;
}

/**
 * @param cadenaIn
 * @param Etiqueta
 * @return limpia linea del clan
 * @throws SQLException 
 */
private static String trataEtiquetaClan (String cadenaIn, String Etiqueta, String Link) throws SQLException {
	String strFich = "";
	

		strFich = "<" +Etiqueta+">"+ cadenaIn.trim() +"</"+Etiqueta+">";
		baseDatos.Clan.insertClan(cadenaIn.trim(), Link);
		return strFich + "\n";
}


/**
 * @param cadenaIn
 * @param Etiqueta
 * @return quita la vasora de la linea del jugador
 * @throws SQLException 
 */
private static String limpiarLineaJugador (String linea) {
	
	String aux = linea;
	
		aux = aux.replaceAll("<DIV class=\"clan__headerCaption\">", "");
		aux = aux.replaceAll("<div class=\"clan__headerCaption\">", "");
		
		aux = aux.replaceAll("<DIV class=\"clan__playerLevel\">", "");
		aux = aux.replaceAll("<div class=\"clan__playerLevel\">", "");
		
		aux = aux.replaceAll("<DIV class=\"league__1\">", "");
		aux = aux.replaceAll("<div class=\"league__1\">", "");
		
		aux = aux.replaceAll("<DIV class=\"clan__cup\">", "");
		aux = aux.replaceAll("<div class=\"clan__cup\">", "");
		
		aux = aux.replaceAll("<DIV class=\"clan__rowContainer\">", "");
		aux = aux.replaceAll("<div class=\"clan__rowContainer\">", "");
		
		aux = aux.replaceAll("<DIV class=\"clan__row\">", "");
		aux = aux.replaceAll("<div class=\"clan__row\">", "");
		
		aux = aux.replaceAll("<A class=\"ui__blueLink\"", "");
		aux = aux.replaceAll("<a class=\"ui__blueLink\"", "");
		
		aux = aux.replaceAll("<SPAN class=\"clan__playerLevel\">", "");
		aux = aux.replaceAll("<span class=\"clan__playerLevel\">", "");
		
		aux = aux.replaceAll("<SPAN", "");
		aux = aux.replaceAll("<span", "");
		
		aux = aux.replaceAll("</A>", "");
		aux = aux.replaceAll("</a>", "");
		
		aux = aux.replaceAll("</DIV>", "");
		aux = aux.replaceAll("</div>", "");
		
		aux = aux.replaceAll("</SPAN>", "");
		aux = aux.replaceAll("</span>", "");
		
	
	return aux.trim();
	
}

/**
 * @param cadenaIn
 * @param Etiqueta
 * @return quita la vasora de la linea del clan
 * @throws SQLException 
 */
private static String limpiarLineaClan (String linea) {
	
	String aux = linea;
	
		aux = aux.replaceAll("<DIV class=\"ui__headerMedium clan__clanName\">", "");
		aux = aux.trim().substring(0,aux.indexOf("<IMG height="));
	
	return aux.trim();
	
}

public static String trataEtiquetaNombre (String cadenaIn, String Etiqueta){
	String NombreRet = "";
	String Name[] = cadenaIn.split(">");
	
		
		if(Name.length==1){
			String aux[] = Name[0].split("/");
			NombreRet = aux[aux.length-1].replaceAll("\"", "");		
		} else{
			NombreRet = Name[Name.length-1].replaceAll("\"", "");
		}
		
	return NombreRet.trim();
}

}
