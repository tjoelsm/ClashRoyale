/**
 * 
 */
package ficheros;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.logging.Logger;

/**
 * @author Familia
 *
 */
public class leerProperties {

	static String ARCHIVO = "C:/tmp/properties.prt";
	
	public static String leerUnaPropertie(String propertie) {
	
		String propReturn = "";
		BufferedReader b = null;
		
	    try{
	    	String cadena = "";
	    	Path temp = Paths.get("");
	    	Path fichTemp = temp.toAbsolutePath();
	        FileReader f = new FileReader(ARCHIVO);
	        b = new BufferedReader(f);
	        boolean encontrado = false;
	        while ( ((cadena = b.readLine())!=null) && (encontrado==false)){	        	
	        	if (cadena.contains(propertie)){
	        		String strBuffer[] = cadena.split("#");
	        		propReturn = strBuffer[1];
	        		encontrado=true;
	        	}
	        }
	        f.close();
	    } catch (IOException e){
	    	System.out.println("ERROR LEYENDO Properties: " + e.getMessage());
	    }
		return propReturn;
	}
	
	public static String leerTodasPropertie() {
	
		
		return "";
	}
	
}
