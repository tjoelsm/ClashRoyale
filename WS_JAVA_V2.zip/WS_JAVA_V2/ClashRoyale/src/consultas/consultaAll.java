package consultas;

public class consultaAll {

}
