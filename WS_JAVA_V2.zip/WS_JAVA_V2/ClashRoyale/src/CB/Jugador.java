package CB;

public class Jugador {
	
	String NAME;
	String LEVEL;
	String LEAGUE;
	String TROPHIES;
	String DONATIONS;
	String ROLE;
	
	public Jugador (){
		this.NAME = "";
	}
	
	public String getName(){
		return NAME;		
	}
	public String getLevel(){
		return LEVEL;		
	}
	
	public String getLeague(){
		return LEAGUE;
	}
	public String getTrophies(){
		return TROPHIES;
	}
	public String getDonations(){
		return DONATIONS;
	}
	public String getRole(){
		return ROLE;	
	}
	
	public void setName(String Str){
		this.NAME = Str;		
	}
	public void setLevel(String Str){
		this.LEVEL= Str;		
	}
	
	public void setLeague(String Str){
		this.LEAGUE= Str;
	}
	public void setTrophies(String Str){
		this.TROPHIES= Str;
	}
	public void setDonations(String Str){
		this.DONATIONS= Str;
	}
	public void setRole(String Str){
		this.ROLE= Str;	
	}
	
}
